# CS336 A1 个人自学代码包

源码和配置位于 implementations/a1-basics/，绘图和 profiling 脚本位于 notes/experiments/。
CSV 和 JSON 提供运行绘图脚本、读取实验配置或核对历史产物所需的少量记录。

## 使用

使用 Python 3.12 和课程 A1 环境。核心代码依赖 PyTorch、NumPy 和 regex，
全量处理还用到 psutil 和 tiktoken，绘图用 ReportLab。
课程环境及官方测试需从 https://github.com/stanford-cs336/assignment1-basics 单独取得。

1. 将 implementations/a1-basics/cs336_basics/ 内的个人模块放入课程 A1 的同名包。
2. 如需运行官方测试，将 adapter_functions.py 中的函数接回 tests/adapters.py，
   保留官方测试和 fixtures。Windows 有两个分词器内存限制测试需要在 Linux 上验证。
3. 根据机器上的数据位置改写配置，或通过训练 CLI 的 --train-data、--val-data 指定 .npy 文件。
   在 A1 根目录运行 python -m cs336_basics.train_cli --help 查看参数。
4. 大语料处理、复现实验和存档格式见源码目录下的 README。
   生成需要本地模型存档及与训练匹配的词表。

实验报告、图表和完整日志可在 https://github.com/jing-56/cs336-learning 查阅。
本包仅收录个人自学实现、配置和复现实验所需的小文件。
FILES.sha256 列出包内文件的 SHA-256。
